// Página Inventario - Gestión completa de productos
// Integra todos los componentes: NavBar, ProductoForm, ProductoTabla y AlertaMensaje
import React, { useState } from 'react';
import NavBar from '../components/NavBar';
import ProductoForm from '../components/ProductoForm';
import ProductoTabla from '../components/ProductoTabla';
import AlertaMensaje from '../components/AlertaMensaje';

const Inventario = ({ usuario, onCerrarSesion }) => {
  // Estado de la lista de productos
  const [productos, setProductos] = useState([
    { id: 1, nombre: 'Base Maquillaje', descripcion: 'Base de larga duración mate', precio: 15000, stock: 50 },
    { id: 2, nombre: 'Labial rojo', descripcion: 'Labial de larga duración', precio: 9000, stock: 40 },
    { id: 3, nombre: 'Polvo suelto', descripcion: 'Polvo traslucido acabado mate', precio: 14000, stock: 25 },
    { id: 4, nombre: 'Sombra ojos', descripcion: 'Sombras satinadas', precio: 20000, stock: 35 },
  ]);

  // Estado del producto que se está editando
  const [productoEditar, setProductoEditar] = useState(null);

  // Estado del mensaje de éxito o error
  const [mensaje, setMensaje] = useState({ tipo: '', texto: '' });

  // Función para agregar o actualizar producto
  const handleGuardar = (nuevoProducto) => {
    if (productoEditar) {
      // Actualiza el producto existente
      setProductos(productos.map((p) =>
        p.id === productoEditar.id
          ? { ...nuevoProducto, id: productoEditar.id }
          : p
      ));
      setMensaje({ tipo: 'exito', texto: 'Producto actualizado correctamente.' });
    } else {
      // Agrega el nuevo producto con un ID nuevo
      const nuevoId = productos.length + 1;
      setProductos([...productos, { ...nuevoProducto, id: nuevoId }]);
      setMensaje({ tipo: 'exito', texto: 'Producto agregado correctamente.' });
    }
    // Limpia el formulario
    setProductoEditar(null);
  };

  // Función para cargar producto en el formulario para editar
  const handleEditar = (producto) => {
    setProductoEditar(producto);
    setMensaje({ tipo: '', texto: '' });
  };

  // Función para eliminar producto
  const handleEliminar = (id) => {
    setProductos(productos.filter((p) => p.id !== id));
    setMensaje({ tipo: 'exito', texto: 'Producto eliminado correctamente.' });
  };

  // Función para limpiar el formulario
  const handleCancelar = () => {
    setProductoEditar(null);
    setMensaje({ tipo: '', texto: '' });
  };

  return (
    <div style={styles.pagina}>
      {/* Barra de navegación */}
      <NavBar
        nombreUsuario={usuario}
        onCerrarSesion={onCerrarSesion}
      />

      <div style={styles.contenedor}>
        {/* Mensaje de éxito o error */}
        <AlertaMensaje tipo={mensaje.tipo} mensaje={mensaje.texto} />

        {/* Formulario agregar/editar */}
        <ProductoForm
          producto={productoEditar}
          onGuardar={handleGuardar}
          onCancelar={handleCancelar}
        />

        {/* Tabla de productos */}
        <ProductoTabla
          productos={productos}
          onEditar={handleEditar}
          onEliminar={handleEliminar}
        />
      </div>
    </div>
  );
};

// Estilos de la página
const styles = {
  pagina: {
    backgroundColor: '#fff0f7',
    minHeight: '100vh',
  },
  contenedor: {
    padding: '20px 30px',
  },
};

export default Inventario;