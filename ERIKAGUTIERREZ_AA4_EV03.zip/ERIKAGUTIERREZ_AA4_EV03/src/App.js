// App.js - Componente principal de KittyStock
// Maneja la navegación entre Login e Inventario
import React, { useState } from 'react';
import LoginForm from './components/LoginForm';
import Inventario from './pages/Inventario';

const App = () => {
  // Estado del usuario logueado
  // Si es null muestra el login, si tiene valor muestra el inventario
  const [usuario, setUsuario] = useState(null);

  // Función que se ejecuta cuando el login es exitoso
  const handleLogin = (correo) => {
    setUsuario(correo);
  };

  // Función para cerrar sesión
  const handleCerrarSesion = () => {
    setUsuario(null);
  };

  return (
    <div>
      {/* Si no hay usuario muestra el login */}
      {usuario === null ? (
        <LoginForm onLogin={handleLogin} />
      ) : (
        /* Si hay usuario muestra el inventario */
        <Inventario
          usuario={usuario}
          onCerrarSesion={handleCerrarSesion}
        />
      )}
    </div>
  );
};

export default App;