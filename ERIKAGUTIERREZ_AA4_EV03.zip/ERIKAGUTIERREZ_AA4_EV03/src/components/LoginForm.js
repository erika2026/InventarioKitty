// Componente LoginForm - Formulario de inicio de sesión
// Maneja la autenticación del usuario en el sistema KittyStock
import React, { useState } from 'react';
import AlertaMensaje from './AlertaMensaje';

const LoginForm = ({ onLogin }) => {
  // Estado del formulario
  const [correo, setCorreo] = useState('');
  const [contrasena, setContrasena] = useState('');
  const [error, setError] = useState('');

  // Maneja el envío del formulario
  const handleSubmit = (e) => {
    e.preventDefault();

    // Validación de campos vacíos
    if (!correo || !contrasena) {
      setError('Por favor completa todos los campos.');
      return;
    }

    // Validación de credenciales de prueba
    if (correo === 'erika@kitty.com' && contrasena === '1234') {
      setError('');
      onLogin(correo);
    } else {
      setError('Correo o contraseña incorrectos.');
    }
  };

  return (
    <div style={styles.contenedor}>
      <div style={styles.card}>
        {/* Título del sistema */}
        <h1 style={styles.titulo}>💄 COSMÉTICOS KITTY</h1>
        <p style={styles.subtitulo}>Sistema de Inventario</p>

        {/* Mensaje de error */}
        <AlertaMensaje tipo="error" mensaje={error} />

        {/* Formulario de login */}
        <form onSubmit={handleSubmit}>
          <input
            style={styles.input}
            type="email"
            placeholder="Correo electrónico"
            value={correo}
            onChange={(e) => setCorreo(e.target.value)}
          />
          <input
            style={styles.input}
            type="password"
            placeholder="Contraseña"
            value={contrasena}
            onChange={(e) => setContrasena(e.target.value)}
          />
          <button style={styles.boton} type="submit">
            Ingresar
          </button>
        </form>
      </div>
    </div>
  );
};

// Estilos del componente
const styles = {
  contenedor: {
    background: 'linear-gradient(#ffe6f0, #ffccdd)',
    height: '100vh',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
  },
  card: {
    background: 'white',
    padding: '40px',
    borderRadius: '10px',
    boxShadow: '0 4px 15px rgba(180,60,120,0.2)',
    width: '350px',
    textAlign: 'center',
  },
  titulo: {
    color: '#b43c78',
    fontSize: '24px',
    marginBottom: '5px',
  },
  subtitulo: {
    color: '#888',
    marginBottom: '20px',
  },
  input: {
    width: '100%',
    padding: '10px',
    margin: '8px 0',
    border: '1px solid #ffb3d1',
    borderRadius: '5px',
    boxSizing: 'border-box',
    fontSize: '14px',
  },
  boton: {
    width: '100%',
    padding: '12px',
    backgroundColor: '#b43c78',
    color: 'white',
    border: 'none',
    borderRadius: '5px',
    fontSize: '16px',
    cursor: 'pointer',
    marginTop: '10px',
  },
};

export default LoginForm;