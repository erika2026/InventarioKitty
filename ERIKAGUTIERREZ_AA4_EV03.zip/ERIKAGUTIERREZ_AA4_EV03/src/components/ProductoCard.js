// Componente ProductoCard - Muestra la información de un producto en la tabla
// Recibe el producto y las funciones de editar y eliminar como props
import React from 'react';

const ProductoCard = ({ producto, onEditar, onEliminar }) => {
  return (
    <tr style={styles.fila}>
      {/* ID del producto */}
      <td style={styles.celda}>{producto.id}</td>

      {/* Nombre del producto */}
      <td style={styles.celda}>{producto.nombre}</td>

      {/* Descripción del producto */}
      <td style={styles.celda}>{producto.descripcion}</td>

      {/* Precio formateado con signo pesos */}
      <td style={styles.celda}>${producto.precio}</td>

      {/* Stock disponible */}
      <td style={styles.celda}>{producto.stock}</td>

      {/* Botones de acción */}
      <td style={styles.celda}>
        <button
          style={styles.botonEditar}
          onClick={() => onEditar(producto)}>
          ✏️ Editar
        </button>
        <button
          style={styles.botonEliminar}
          onClick={() => {
            // Confirmación antes de eliminar
            if (window.confirm('¿Eliminar este producto?')) {
              onEliminar(producto.id);
            }
          }}>
          🗑️ Eliminar
        </button>
      </td>
    </tr>
  );
};

// Estilos del componente
const styles = {
  fila: {
    borderBottom: '1px solid #ffe0f0',
  },
  celda: {
    padding: '10px 12px',
    fontSize: '13px',
  },
  botonEditar: {
    padding: '6px 12px',
    backgroundColor: '#007bff',
    color: 'white',
    border: 'none',
    borderRadius: '5px',
    cursor: 'pointer',
    marginRight: '5px',
    fontSize: '13px',
  },
  botonEliminar: {
    padding: '6px 12px',
    backgroundColor: '#dc3545',
    color: 'white',
    border: 'none',
    borderRadius: '5px',
    cursor: 'pointer',
    fontSize: '13px',
  },
};

export default ProductoCard;