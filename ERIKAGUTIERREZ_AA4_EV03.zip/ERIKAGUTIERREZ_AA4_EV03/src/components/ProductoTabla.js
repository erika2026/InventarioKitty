// Componente ProductoTabla - Muestra la lista de todos los productos
// Se actualiza automáticamente cuando se agrega, edita o elimina un producto
import React from 'react';
import ProductoCard from './ProductoCard';

const ProductoTabla = ({ productos, onEditar, onEliminar }) => {
  return (
    <div style={styles.contenedor}>
      {/* Verifica si hay productos para mostrar */}
      {productos.length === 0 ? (
        <div style={styles.vacio}>
          No hay productos registrados aún.
        </div>
      ) : (
        <table style={styles.tabla}>
          {/* Encabezados de la tabla */}
          <thead>
            <tr>
              <th style={styles.encabezado}>ID</th>
              <th style={styles.encabezado}>Nombre</th>
              <th style={styles.encabezado}>Descripción</th>
              <th style={styles.encabezado}>Precio</th>
              <th style={styles.encabezado}>Stock</th>
              <th style={styles.encabezado}>Acciones</th>
            </tr>
          </thead>

          {/* Filas de productos */}
          <tbody>
            {productos.map((producto) => (
              <ProductoCard
                key={producto.id}
                producto={producto}
                onEditar={onEditar}
                onEliminar={onEliminar}
              />
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

// Estilos del componente
const styles = {
  contenedor: {
    backgroundColor: 'white',
    borderRadius: '10px',
    overflow: 'hidden',
    boxShadow: '0 2px 10px rgba(180,60,120,0.1)',
  },
  tabla: {
    width: '100%',
    borderCollapse: 'collapse',
  },
  encabezado: {
    backgroundColor: '#b43c78',
    color: 'white',
    padding: '12px',
    textAlign: 'left',
    fontSize: '13px',
  },
  vacio: {
    textAlign: 'center',
    color: '#888',
    padding: '30px',
  },
};

export default ProductoTabla;