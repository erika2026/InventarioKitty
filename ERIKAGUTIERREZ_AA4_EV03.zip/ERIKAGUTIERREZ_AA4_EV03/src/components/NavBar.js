// Componente NavBar - Barra de navegación superior
// Muestra el nombre del sistema, usuario logueado y botón cerrar sesión
import React from 'react';

const NavBar = ({ nombreUsuario, onCerrarSesion }) => {
  return (
    <nav style={styles.nav}>
      {/* Logo y nombre del sistema */}
      <div style={styles.logo}>
        💄 KittyStock - Cosméticos KITTY
      </div>

      {/* Información del usuario */}
      <div style={styles.usuario}>
        <span>Bienvenido, <strong>{nombreUsuario}</strong></span>
        <button
          style={styles.boton}
          onClick={onCerrarSesion}>
          Cerrar sesión
        </button>
      </div>
    </nav>
  );
};

// Estilos del componente
const styles = {
  nav: {
    backgroundColor: '#b43c78',
    color: 'white',
    padding: '15px 30px',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  logo: {
    fontSize: '20px',
    fontWeight: 'bold',
  },
  usuario: {
    display: 'flex',
    alignItems: 'center',
    gap: '15px',
  },
  boton: {
    backgroundColor: '#922f60',
    color: 'white',
    border: 'none',
    padding: '8px 15px',
    borderRadius: '5px',
    cursor: 'pointer',
  },
};

export default NavBar;