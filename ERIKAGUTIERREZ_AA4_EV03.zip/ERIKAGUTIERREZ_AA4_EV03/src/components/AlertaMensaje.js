// Componente AlertaMensaje - Muestra mensajes de éxito o error al usuario
import React from 'react';

const AlertaMensaje = ({ tipo, mensaje }) => {
  // Si no hay mensaje no muestra nada
  if (!mensaje) return null;

  return (
    <div style={tipo === 'error' ? styles.error : styles.exito}>
      {/* Icono según el tipo de mensaje */}
      {tipo === 'error' ? '⚠️' : '✅'} {mensaje}
    </div>
  );
};

// Estilos del componente
const styles = {
  error: {
    backgroundColor: '#ffe0e0',
    color: 'red',
    padding: '10px 15px',
    borderRadius: '5px',
    marginBottom: '15px',
    fontWeight: 'bold',
    fontSize: '14px',
  },
  exito: {
    backgroundColor: '#e0ffe0',
    color: 'green',
    padding: '10px 15px',
    borderRadius: '5px',
    marginBottom: '15px',
    fontWeight: 'bold',
    fontSize: '14px',
  },
};

export default AlertaMensaje;