// Componente ProductoForm - Formulario para agregar y editar productos
// Si recibe un producto como prop es edición, si no es agregar nuevo
import React, { useState, useEffect } from 'react';

const ProductoForm = ({ producto, onGuardar, onCancelar }) => {
  // Estado del formulario
  const [nombre, setNombre] = useState('');
  const [descripcion, setDescripcion] = useState('');
  const [precio, setPrecio] = useState('');
  const [stock, setStock] = useState('');

  // Si recibe un producto carga sus datos para editar
  useEffect(() => {
    if (producto) {
      setNombre(producto.nombre);
      setDescripcion(producto.descripcion);
      setPrecio(producto.precio);
      setStock(producto.stock);
    }
  }, [producto]);

  // Maneja el envío del formulario
  const handleSubmit = (e) => {
    e.preventDefault();

    // Validación de campos obligatorios
    if (!nombre || !precio || !stock) {
      alert('Por favor completa los campos obligatorios.');
      return;
    }

    // Crea el objeto producto con los datos del formulario
    const nuevoProducto = {
      nombre,
      descripcion,
      precio: parseFloat(precio),
      stock: parseInt(stock),
    };

    onGuardar(nuevoProducto);
  };

  return (
    <div style={styles.card}>
      <h2 style={styles.titulo}>
        {/* Cambia el título según si es editar o agregar */}
        {producto ? '✏️ Editar Producto' : '➕ Agregar Producto'}
      </h2>

      <form onSubmit={handleSubmit}>
        {/* Campo nombre */}
        <input
          style={styles.input}
          type="text"
          placeholder="Nombre del producto *"
          value={nombre}
          onChange={(e) => setNombre(e.target.value)}
        />

        {/* Campo descripción */}
        <input
          style={styles.input}
          type="text"
          placeholder="Descripción"
          value={descripcion}
          onChange={(e) => setDescripcion(e.target.value)}
        />

        {/* Campo precio */}
        <input
          style={styles.input}
          type="number"
          placeholder="Precio *"
          value={precio}
          onChange={(e) => setPrecio(e.target.value)}
        />

        {/* Campo stock */}
        <input
          style={styles.input}
          type="number"
          placeholder="Stock *"
          value={stock}
          onChange={(e) => setStock(e.target.value)}
        />

        {/* Botones de acción */}
        <div style={styles.botones}>
          <button style={styles.botonGuardar} type="submit">
            {producto ? '✏️ Actualizar' : '➕ Agregar'}
          </button>
          <button
            style={styles.botonCancelar}
            type="button"
            onClick={onCancelar}>
            🔄 Limpiar
          </button>
        </div>
      </form>
    </div>
  );
};

// Estilos del componente
const styles = {
  card: {
    backgroundColor: 'white',
    padding: '20px',
    borderRadius: '10px',
    border: '1px solid #ffb3d1',
    marginBottom: '20px',
  },
  titulo: {
    color: '#b43c78',
    fontSize: '16px',
    marginBottom: '15px',
  },
  input: {
    width: '100%',
    padding: '8px',
    margin: '6px 0',
    border: '1px solid #ffb3d1',
    borderRadius: '5px',
    boxSizing: 'border-box',
    fontSize: '13px',
  },
  botones: {
    display: 'flex',
    gap: '10px',
    marginTop: '10px',
  },
  botonGuardar: {
    padding: '9px 18px',
    backgroundColor: '#28a745',
    color: 'white',
    border: 'none',
    borderRadius: '5px',
    cursor: 'pointer',
    fontSize: '13px',
  },
  botonCancelar: {
    padding: '9px 18px',
    backgroundColor: '#6c757d',
    color: 'white',
    border: 'none',
    borderRadius: '5px',
    cursor: 'pointer',
    fontSize: '13px',
  },
};

export default ProductoForm;