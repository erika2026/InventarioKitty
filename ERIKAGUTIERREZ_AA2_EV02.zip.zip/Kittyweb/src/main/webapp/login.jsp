<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Cosméticos KITTY — Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(#ffe6f0, #ffccdd);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .card {
            background: white;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(180,60,120,0.2);
            width: 350px;
            text-align: center;
        }
        h1 { color: #b43c78; font-size: 24px; }
        p  { color: #888; margin-bottom: 20px; }
        input {
            width: 100%;
            padding: 10px;
            margin: 8px 0;
            border: 1px solid #ffb3d1;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 14px;
        }
        button {
            width: 100%;
            padding: 12px;
            background: #b43c78;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            margin-top: 10px;
        }
        button:hover { background: #922f60; }
        .error { color: red; font-size: 13px; margin-top: 10px; }
        .link  { margin-top: 15px; font-size: 13px; }
        .link a { color: #b43c78; }
    </style>
</head>
<body>
    <div class="card">
        <h1>💄 COSMÉTICOS KITTY</h1>
        <p>Sistema de Inventario</p>

        <% String error = (String) request.getAttribute("error");
           if (error != null) { %>
            <div class="error">⚠️ <%= error %></div>
        <% } %>

        <form action="LoginServlet" method="post">
            <input type="email"
                   name="correo"
                   placeholder="Correo electrónico"
                   required/>
            <input type="password"
                   name="contrasena"
                   placeholder="Contraseña"
                   required/>
            <button type="submit">Ingresar</button>
        </form>

        <div class="link">
            ¿No tienes cuenta?
            <a href="RegistroServlet">Regístrate aquí</a>
        </div>
    </div>
</body>
</html>