<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.util.List"%>
<%@page import="com.cosmeticos.kitty.modelo.Producto"%>
<%@page import="com.cosmeticos.kitty.modelo.Usuario"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Cosméticos KITTY — Inventario</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: Arial, sans-serif; background: #fff0f7; }
        .header {
            background: #b43c78;
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .header h1 { font-size: 20px; }
        .header a {
            color: white;
            background: #922f60;
            padding: 8px 15px;
            border-radius: 5px;
            text-decoration: none;
        }
        .container { padding: 20px 30px; }
        .form-card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            border: 1px solid #ffb3d1;
            margin-bottom: 20px;
        }
        .form-card h2 { color: #b43c78; margin-bottom: 15px; font-size: 16px; }
        .form-row { display: flex; gap: 10px; flex-wrap: wrap; }
        .form-row input {
            flex: 1;
            min-width: 150px;
            padding: 8px;
            border: 1px solid #ffb3d1;
            border-radius: 5px;
            font-size: 13px;
        }
        .btn {
            padding: 9px 18px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 13px;
            color: white;
        }
        .btn-insertar  { background: #28a745; }
        .btn-actualizar{ background: #007bff; }
        .btn-eliminar  { background: #dc3545; }
        .btn-limpiar   { background: #6c757d; }
        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(180,60,120,0.1);
        }
        th {
            background: #b43c78;
            color: white;
            padding: 12px;
            text-align: left;
            font-size: 13px;
        }
        td {
            padding: 10px 12px;
            border-bottom: 1px solid #ffe0f0;
            font-size: 13px;
        }
        tr:hover { background: #fff0f7; }
        .mensaje-ok  { color: green; margin-bottom: 10px; font-weight: bold; }
        .mensaje-err { color: red;   margin-bottom: 10px; font-weight: bold; }
    </style>
</head>
<body>

<%-- Verificar sesión --%>
<%
    Usuario usuarioLogueado = (Usuario) session.getAttribute("usuarioLogueado");
    if (usuarioLogueado == null) {
        response.sendRedirect("LoginServlet");
        return;
    }
%>

<div class="header">
    <h1>💄 Cosméticos KITTY — Inventario</h1>
    <div>
        Bienvenido, <strong><%= usuarioLogueado.getNombre() %></strong>
        &nbsp;|&nbsp;
        <a href="LoginServlet?accion=salir">Cerrar sesión</a>
    </div>
</div>

<div class="container">

    <%-- Mensajes --%>
    <% String error = (String) request.getAttribute("error");
       if (error != null) { %>
        <div class="mensaje-err">⚠️ <%= error %></div>
    <% } %>

    <%-- Formulario agregar/editar producto --%>
    <div class="form-card">
        <h2>📦 Registrar / Editar Producto</h2>
        <%
            Producto editar = (Producto) request.getAttribute("producto");
            String accionForm = (editar != null) ? "actualizar" : "insertar";
        %>
        <form action="ProductoServlet" method="post">
            <input type="hidden" name="accion" value="<%= accionForm %>"/>
            <% if (editar != null) { %>
                <input type="hidden" name="idProducto" value="<%= editar.getIdProducto() %>"/>
            <% } %>
            <div class="form-row">
                <input type="text"
                       name="nombre"
                       placeholder="Nombre del producto"
                       value="<%= editar != null ? editar.getNombre() : "" %>"
                       required/>
                <input type="text"
                       name="descripcion"
                       placeholder="Descripción"
                       value="<%= editar != null ? editar.getDescripcion() : "" %>"/>
                <input type="number"
                       name="precio"
                       placeholder="Precio"
                       step="0.01"
                       value="<%= editar != null ? editar.getPrecio() : "" %>"
                       required/>
                <input type="number"
                       name="stock"
                       placeholder="Stock"
                       value="<%= editar != null ? editar.getStock() : "" %>"
                       required/>
                <input type="number"
                       name="idCategoria"
                       placeholder="ID Categoría"
                       value="<%= editar != null ? editar.getIdCategoria() : "1" %>"
                       required/>
            </div>
            <div style="margin-top:10px; display:flex; gap:10px;">
                <button type="submit" class="btn btn-insertar">
                    <%= accionForm.equals("actualizar") ? "✏️ Actualizar" : "➕ Agregar" %>
                </button>
                <a href="ProductoServlet" class="btn btn-limpiar"
                   style="text-decoration:none; padding:9px 18px;">
                    🔄 Limpiar
                </a>
            </div>
        </form>
    </div>

    <%-- Tabla de productos --%>
    <% List<Producto> productos = (List<Producto>) request.getAttribute("productos");
       if (productos != null && !productos.isEmpty()) { %>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Descripción</th>
                    <th>Precio</th>
                    <th>Stock</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <% for (Producto p : productos) { %>
                <tr>
                    <td><%= p.getIdProducto() %></td>
                    <td><%= p.getNombre() %></td>
                    <td><%= p.getDescripcion() %></td>
                    <td>$<%= p.getPrecio() %></td>
                    <td><%= p.getStock() %></td>
                    <td>
                        <a href="ProductoServlet?accion=editar&id=<%= p.getIdProducto() %>"
                           class="btn btn-actualizar"
                           style="text-decoration:none; padding:6px 12px;">
                           ✏️ Editar
                        </a>
                        <a href="ProductoServlet?accion=eliminar&id=<%= p.getIdProducto() %>"
                           class="btn btn-eliminar"
                           style="text-decoration:none; padding:6px 12px;"
                           onclick="return confirm('¿Eliminar este producto?')">
                           🗑️ Eliminar
                        </a>
                    </td>
                </tr>
                <% } %>
            </tbody>
        </table>
    <% } else { %>
        <div class="form-card" style="text-align:center; color:#888;">
            No hay productos registrados aún.
        </div>
    <% } %>

</div>
</body>
</html>