package com.cosmeticos.kitty.modelo;

public class Producto {

    private int    idProducto;
    private String nombre;
    private String descripcion;
    private double precio;
    private int    stock;
    private int    idCategoria;
    private String fechaRegistro;
    private int    estado;

    public Producto() {}

    // Getters y Setters
    public int getIdProducto()                      { return idProducto; }
    public void setIdProducto(int idProducto)       { this.idProducto = idProducto; }

    public String getNombre()                       { return nombre; }
    public void setNombre(String nombre)            { this.nombre = nombre; }

    public String getDescripcion()                  { return descripcion; }
    public void setDescripcion(String descripcion)  { this.descripcion = descripcion; }

    public double getPrecio()                       { return precio; }
    public void setPrecio(double precio)            { this.precio = precio; }

    public int getStock()                           { return stock; }
    public void setStock(int stock)                 { this.stock = stock; }

    public int getIdCategoria()                     { return idCategoria; }
    public void setIdCategoria(int idCategoria)     { this.idCategoria = idCategoria; }

    public String getFechaRegistro()                    { return fechaRegistro; }
    public void setFechaRegistro(String fechaRegistro)  { this.fechaRegistro = fechaRegistro; }

    public int getEstado()                          { return estado; }
    public void setEstado(int estado)               { this.estado = estado; }
}