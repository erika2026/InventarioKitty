package com.cosmeticos.kitty.modelo;

public class Usuario {

    private int    idUsuario;
    private String nombre;
    private String correo;
    private String contrasena;
    private String rol;
    private String estado;

    public Usuario() {}

    // Getters y Setters
    public int getIdUsuario()                       { return idUsuario; }
    public void setIdUsuario(int idUsuario)         { this.idUsuario = idUsuario; }

    public String getNombre()                       { return nombre; }
    public void setNombre(String nombre)            { this.nombre = nombre; }

    public String getCorreo()                       { return correo; }
    public void setCorreo(String correo)            { this.correo = correo; }

    public String getContrasena()                   { return contrasena; }
    public void setContrasena(String contrasena)    { this.contrasena = contrasena; }

    public String getRol()                          { return rol; }
    public void setRol(String rol)                  { this.rol = rol; }

    public String getEstado()                       { return estado; }
    public void setEstado(String estado)            { this.estado = estado; }
}