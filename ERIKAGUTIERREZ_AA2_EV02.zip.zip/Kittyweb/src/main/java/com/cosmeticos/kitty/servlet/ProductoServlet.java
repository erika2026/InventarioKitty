package com.cosmeticos.kitty.servlet;

import com.cosmeticos.kitty.dao.ProductoDAO;
import com.cosmeticos.kitty.modelo.Producto;
import java.io.IOException;
import java.util.List;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/ProductoServlet")
public class ProductoServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Verificar sesión activa
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("usuarioLogueado") == null) {
            response.sendRedirect("LoginServlet");
            return;
        }

        String accion = request.getParameter("accion");
        if (accion == null) accion = "listar";

        ProductoDAO dao = new ProductoDAO();

        switch (accion) {
            case "listar":
                List<Producto> lista = dao.listarTodos();
                request.setAttribute("productos", lista);
                request.getRequestDispatcher("/inventario.jsp")
                       .forward(request, response);
                break;

            case "editar":
                int idEditar = Integer.parseInt(request.getParameter("id"));
                Producto p = dao.buscarPorId(idEditar);
                request.setAttribute("producto", p);
                request.getRequestDispatcher("/inventario.jsp")
                       .forward(request, response);
                break;

            case "eliminar":
                int idEliminar = Integer.parseInt(request.getParameter("id"));
                dao.eliminar(idEliminar);
                response.sendRedirect("ProductoServlet");
                break;

            default:
                response.sendRedirect("ProductoServlet");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Verificar sesión activa
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("usuarioLogueado") == null) {
            response.sendRedirect("LoginServlet");
            return;
        }

        String accion = request.getParameter("accion");

        String nombre      = request.getParameter("nombre");
        String descripcion = request.getParameter("descripcion");
        double precio      = Double.parseDouble(request.getParameter("precio"));
        int stock          = Integer.parseInt(request.getParameter("stock"));
        int idCategoria    = Integer.parseInt(request.getParameter("idCategoria"));

        Producto p = new Producto();
        p.setNombre(nombre);
        p.setDescripcion(descripcion);
        p.setPrecio(precio);
        p.setStock(stock);
        p.setIdCategoria(idCategoria);

        ProductoDAO dao = new ProductoDAO();

        if ("insertar".equals(accion)) {
            dao.insertar(p);
        } else if ("actualizar".equals(accion)) {
            int id = Integer.parseInt(request.getParameter("idProducto"));
            p.setIdProducto(id);
            dao.actualizar(p);
        }

        response.sendRedirect("ProductoServlet");
    }
}