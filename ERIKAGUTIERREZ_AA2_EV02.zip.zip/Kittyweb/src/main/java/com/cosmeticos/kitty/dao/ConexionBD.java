package com.cosmeticos.kitty.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionBD {

    private static final String URL     = "jdbc:mysql://localhost:3306/cosmeticos_kitty"
                                        + "?useSSL=false&serverTimezone=America/Bogota";
    private static final String USUARIO = "root";
    private static final String CLAVE   = "root";

    private ConexionBD() {}

    public static Connection getConnection() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection(URL, USUARIO, CLAVE);
        } catch (ClassNotFoundException e) {
            throw new SQLException("Driver MySQL no encontrado: " + e.getMessage());
        }
    }

    public static void cerrar(Connection con) {
        if (con != null) {
            try { con.close(); }
            catch (SQLException e) {
                System.err.println("Error al cerrar: " + e.getMessage());
            }
        }
    }
}