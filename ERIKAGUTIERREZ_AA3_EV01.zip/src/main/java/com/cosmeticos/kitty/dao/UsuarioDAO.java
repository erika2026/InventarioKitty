package com.cosmeticos.kitty.dao;

import com.cosmeticos.kitty.modelo.Usuario;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 * DAO de Usuario usando Hibernate.
 * Gestiona autenticación y registro de usuarios.
 * @author Erika
 */
public class UsuarioDAO {

    /**
     * Autentica un usuario verificando correo y contraseña.
     * @param correo Correo del usuario
     * @param contrasena Contraseña del usuario
     * @return Usuario autenticado o null si no existe
     */
    public Usuario autenticar(String correo, String contrasena) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            // HQL con parámetros nombrados para evitar SQL injection
            return session.createQuery(
                "FROM Usuario WHERE correo = :correo " +
                "AND contrasena = :contrasena " +
                "AND estado = 'activo'",
                Usuario.class
            )
            .setParameter("correo", correo)
            .setParameter("contrasena", contrasena)
            .uniqueResult(); // Retorna un único resultado
        } catch (Exception e) {
            System.err.println("Error al autenticar: " + e.getMessage());
            return null;
        }
    }

    /**
     * Verifica si un correo ya está registrado en el sistema.
     * @param correo Correo a verificar
     * @return true si ya existe, false si está disponible
     */
    public boolean existeCorreo(String correo) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Long cantidad = session.createQuery(
                "SELECT COUNT(u) FROM Usuario u WHERE u.correo = :correo",
                Long.class
            )
            .setParameter("correo", correo)
            .uniqueResult();
            // Si cantidad es mayor a 0, el correo ya existe
            return cantidad != null && cantidad > 0;
        } catch (Exception e) {
            System.err.println("Error al verificar correo: " + e.getMessage());
            return false;
        }
    }

    /**
     * Registra un nuevo usuario en la base de datos.
     * Por defecto se asigna rol 'vendedor' y estado 'activo'.
     * @param usuario Objeto Usuario a registrar
     * @return true si se registró correctamente, false si hubo error
     */
    public boolean registrar(Usuario usuario) {
        Transaction tx = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            tx = session.beginTransaction();
            // Valores por defecto para nuevos usuarios
            usuario.setRol("vendedor");
            usuario.setEstado("activo");
            session.persist(usuario);
            tx.commit();
            return true; // Registro exitoso
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            System.err.println("Error al registrar usuario: " + e.getMessage());
            return false;
        }
    }
}