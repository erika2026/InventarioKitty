package com.cosmeticos.kitty.dao;

import com.cosmeticos.kitty.modelo.Producto;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 * DAO de Producto usando Hibernate.
 * Gestiona las operaciones CRUD sobre la tabla 'productos'.
 * @author Erika
 */
public class ProductoDAO {

    /**
     * Lista todos los productos activos ordenados por nombre.
     * @return Lista de productos activos
     */
    public List<Producto> listarTodos() {
        // Abre sesión de Hibernate
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            // HQL: lenguaje de consulta de Hibernate (parecido a SQL pero con clases Java)
            return session.createQuery(
                "FROM Producto WHERE estado = 1 ORDER BY nombre",
                Producto.class
            ).list();
        }
    }

    /**
     * Busca un producto por su ID.
     * @param id Identificador del producto
     * @return Producto encontrado o null si no existe
     */
    public Producto buscarPorId(int id) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            // session.get busca directamente por llave primaria
            return session.get(Producto.class, id);
        }
    }

    /**
     * Inserta un nuevo producto en la base de datos.
     * @param producto Objeto Producto a insertar
     */
    public void insertar(Producto producto) {
        Transaction tx = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            // Inicia transacción para operaciones de escritura
            tx = session.beginTransaction();
            session.persist(producto);
            tx.commit(); // Confirma los cambios en la BD
        } catch (Exception e) {
            // Si algo falla, revierte los cambios
            if (tx != null) tx.rollback();
            System.err.println("Error al insertar producto: " + e.getMessage());
        }
    }

    /**
     * Actualiza un producto existente en la base de datos.
     * @param producto Objeto Producto con los datos actualizados
     */
    public void actualizar(Producto producto) {
        Transaction tx = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            tx = session.beginTransaction();
            session.merge(producto); // merge actualiza si ya existe
            tx.commit();
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            System.err.println("Error al actualizar producto: " + e.getMessage());
        }
    }

    /**
     * Elimina lógicamente un producto (cambia estado a 0).
     * No se borra físicamente de la BD.
     * @param id Identificador del producto a eliminar
     */
    public void eliminar(int id) {
        Transaction tx = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            tx = session.beginTransaction();
            // Eliminación lógica: solo cambia el estado a 0
            Producto p = session.get(Producto.class, id);
            if (p != null) {
                p.setEstado(0);
                session.merge(p);
            }
            tx.commit();
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            System.err.println("Error al eliminar producto: " + e.getMessage());
        }
    }
}