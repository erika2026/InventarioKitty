package com.cosmeticos.kitty.dao;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

/**
 * Clase utilitaria para gestionar la SessionFactory de Hibernate.
 * Implementa el patrón Singleton para garantizar una única instancia.
 * @author Erika
 */
public class HibernateUtil {

    /** Instancia única de SessionFactory (patrón Singleton) */
    private static SessionFactory sessionFactory;

    /** Constructor privado para evitar instanciación directa */
    private HibernateUtil() {}

    /**
     * Retorna la instancia única de SessionFactory.
     * Si no existe, la crea leyendo hibernate.cfg.xml
     * @return SessionFactory configurada
     */
    public static SessionFactory getSessionFactory() {
        if (sessionFactory == null) {
            try {
                // Lee la configuración desde hibernate.cfg.xml
                sessionFactory = new Configuration()
                        .configure("hibernate.cfg.xml")
                        .buildSessionFactory();
            } catch (Exception e) {
                System.err.println("Error al crear SessionFactory: " 
                        + e.getMessage());
                throw new RuntimeException(e);
            }
        }
        return sessionFactory;
    }

    /**
     * Cierra la SessionFactory al apagar la aplicación.
     * Libera todos los recursos de Hibernate.
     */
    public static void shutdown() {
        if (sessionFactory != null && !sessionFactory.isClosed()) {
            sessionFactory.close();
        }
    }
}