package com.cosmeticos.kitty.servlet;

import com.cosmeticos.kitty.dao.UsuarioDAO;
import com.cosmeticos.kitty.modelo.Usuario;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 * Servlet que gestiona el inicio y cierre de sesión.
 * Maneja las peticiones GET para mostrar el formulario
 * y POST para procesar las credenciales del usuario.
 * @author Erika
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {

    /**
     * Maneja peticiones GET.
     * Si se recibe accion=salir, cierra la sesión activa.
     * De lo contrario, muestra el formulario de login.
     * @param request  Petición HTTP del cliente
     * @param response Respuesta HTTP al cliente
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Verifica si el usuario quiere cerrar sesión
        String accion = request.getParameter("accion");
        if ("salir".equals(accion)) {
            // Obtiene la sesión actual sin crear una nueva
            HttpSession session = request.getSession(false);
            if (session != null) {
                session.invalidate(); // Destruye la sesión
            }
            response.sendRedirect("LoginServlet");
            return;
        }

        // Muestra el formulario de inicio de sesión
        request.getRequestDispatcher("/login.jsp").forward(request, response);
    }

    /**
     * Maneja peticiones POST.
     * Valida las credenciales y crea la sesión si son correctas.
     * @param request  Petición HTTP con correo y contraseña
     * @param response Respuesta HTTP al cliente
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Obtiene los parámetros del formulario
        String correo     = request.getParameter("correo");
        String contrasena = request.getParameter("contrasena");

        // Valida que los campos no estén vacíos
        if (correo == null || correo.trim().isEmpty() ||
            contrasena == null || contrasena.trim().isEmpty()) {
            request.setAttribute("error", "Por favor completa todos los campos.");
            request.getRequestDispatcher("/login.jsp").forward(request, response);
            return;
        }

        // Intenta autenticar al usuario con la base de datos
        UsuarioDAO dao = new UsuarioDAO();
        Usuario usuario = dao.autenticar(correo.trim(), contrasena.trim());

        if (usuario != null) {
            // Credenciales correctas: crea sesión y guarda datos del usuario
            HttpSession session = request.getSession();
            session.setAttribute("usuarioLogueado", usuario);
            session.setAttribute("nombreUsuario", usuario.getNombre());
            session.setAttribute("rolUsuario", usuario.getRol());

            // Redirige al inventario
            response.sendRedirect("ProductoServlet");
        } else {
            // Credenciales incorrectas: muestra mensaje de error
            request.setAttribute("error", "Correo o contraseña incorrectos.");
            request.getRequestDispatcher("/login.jsp").forward(request, response);
        }
    }
}