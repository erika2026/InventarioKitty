package com.cosmeticos.kitty.servlet;

import com.cosmeticos.kitty.dao.ProductoDAO;
import com.cosmeticos.kitty.modelo.Producto;
import java.io.IOException;
import java.util.List;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 * Servlet que gestiona el inventario de productos.
 * Maneja operaciones CRUD: listar, insertar, actualizar y eliminar.
 * Requiere sesión activa para acceder.
 * @author Erika
 */
@WebServlet("/ProductoServlet")
public class ProductoServlet extends HttpServlet {

    /**
     * Maneja peticiones GET.
     * Controla las acciones: listar, editar y eliminar productos.
     * @param request  Petición HTTP del cliente
     * @param response Respuesta HTTP al cliente
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Verifica que exista una sesión activa
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("usuarioLogueado") == null) {
            // Si no hay sesión, redirige al login
            response.sendRedirect("LoginServlet");
            return;
        }

        // Obtiene la acción a realizar, por defecto lista productos
        String accion = request.getParameter("accion");
        if (accion == null) accion = "listar";

        // Instancia el DAO para operaciones con la BD
        ProductoDAO dao = new ProductoDAO();

        switch (accion) {
            case "listar":
                // Obtiene todos los productos activos y los envía a la vista
                List<Producto> lista = dao.listarTodos();
                request.setAttribute("productos", lista);
                request.getRequestDispatcher("/inventario.jsp")
                       .forward(request, response);
                break;

            case "editar":
                // Busca el producto por ID y lo envía a la vista para editar
                int idEditar = Integer.parseInt(request.getParameter("id"));
                Producto p = dao.buscarPorId(idEditar);
                request.setAttribute("producto", p);
                request.getRequestDispatcher("/inventario.jsp")
                       .forward(request, response);
                break;

            case "eliminar":
                // Elimina lógicamente el producto y recarga la lista
                int idEliminar = Integer.parseInt(request.getParameter("id"));
                dao.eliminar(idEliminar);
                response.sendRedirect("ProductoServlet");
                break;

            default:
                // Acción no reconocida: regresa al listado
                response.sendRedirect("ProductoServlet");
        }
    }

    /**
     * Maneja peticiones POST.
     * Controla las acciones: insertar y actualizar productos.
     * @param request  Petición HTTP con datos del formulario
     * @param response Respuesta HTTP al cliente
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Verifica que exista una sesión activa
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("usuarioLogueado") == null) {
            response.sendRedirect("LoginServlet");
            return;
        }

        // Obtiene la acción y los datos del formulario
        String accion      = request.getParameter("accion");
        String nombre      = request.getParameter("nombre");
        String descripcion = request.getParameter("descripcion");
        double precio      = Double.parseDouble(request.getParameter("precio"));
        int stock          = Integer.parseInt(request.getParameter("stock"));
        int idCategoria    = Integer.parseInt(request.getParameter("idCategoria"));

        // Construye el objeto Producto con los datos del formulario
        Producto p = new Producto();
        p.setNombre(nombre);
        p.setDescripcion(descripcion);
        p.setPrecio(precio);
        p.setStock(stock);
        p.setIdCategoria(idCategoria);
        p.setEstado(1); // Estado activo por defecto

        // Instancia el DAO para operaciones con la BD
        ProductoDAO dao = new ProductoDAO();

        if ("insertar".equals(accion)) {
            // Inserta el nuevo producto en la base de datos
            dao.insertar(p);
        } else if ("actualizar".equals(accion)) {
            // Actualiza el producto existente con el ID recibido
            int id = Integer.parseInt(request.getParameter("idProducto"));
            p.setIdProducto(id);
            dao.actualizar(p);
        }

        // Recarga el listado de productos
        response.sendRedirect("ProductoServlet");
    }
}