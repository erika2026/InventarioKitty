package com.cosmeticos.kitty.servlet;

import com.cosmeticos.kitty.dao.UsuarioDAO;
import com.cosmeticos.kitty.modelo.Usuario;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet que gestiona el registro de nuevos usuarios.
 * Maneja peticiones GET para mostrar el formulario
 * y POST para procesar y guardar el nuevo usuario.
 * @author Erika
 */
@WebServlet("/RegistroServlet")
public class RegistroServlet extends HttpServlet {

    /**
     * Maneja peticiones GET.
     * Muestra el formulario de registro de usuario.
     * @param request  Petición HTTP del cliente
     * @param response Respuesta HTTP al cliente
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Muestra el formulario de registro
        request.getRequestDispatcher("/registro.jsp").forward(request, response);
    }

    /**
     * Maneja peticiones POST.
     * Valida los datos y registra el nuevo usuario en la BD.
     * @param request  Petición HTTP con los datos del formulario
     * @param response Respuesta HTTP al cliente
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Obtiene los parámetros del formulario de registro
        String nombre     = request.getParameter("nombre");
        String correo     = request.getParameter("correo");
        String contrasena = request.getParameter("contrasena");
        String confirmar  = request.getParameter("confirmar");

        // Valida que ningún campo esté vacío
        if (nombre == null || nombre.trim().isEmpty() ||
            correo == null || correo.trim().isEmpty() ||
            contrasena == null || contrasena.trim().isEmpty()) {
            request.setAttribute("error", "Todos los campos son obligatorios.");
            request.getRequestDispatcher("/registro.jsp").forward(request, response);
            return;
        }

        // Valida que las contraseñas coincidan
        if (!contrasena.equals(confirmar)) {
            request.setAttribute("error", "Las contraseñas no coinciden.");
            request.getRequestDispatcher("/registro.jsp").forward(request, response);
            return;
        }

        // Verifica que el correo no esté ya registrado
        UsuarioDAO dao = new UsuarioDAO();
        if (dao.existeCorreo(correo.trim())) {
            request.setAttribute("error", "Ese correo ya está registrado.");
            request.getRequestDispatcher("/registro.jsp").forward(request, response);
            return;
        }

        // Crea el objeto Usuario con los datos del formulario
        Usuario u = new Usuario();
        u.setNombre(nombre.trim());
        u.setCorreo(correo.trim());
        u.setContrasena(contrasena.trim());

        // Intenta registrar el usuario en la base de datos
        if (dao.registrar(u)) {
            // Registro exitoso: redirige al login con mensaje
            request.setAttribute("mensaje", "Registro exitoso. Ya puedes iniciar sesión.");
            request.getRequestDispatcher("/login.jsp").forward(request, response);
        } else {
            // Error al registrar: muestra mensaje de error
            request.setAttribute("error", "Error al registrar. Intenta de nuevo.");
            request.getRequestDispatcher("/registro.jsp").forward(request, response);
        }
    }
}