package com.cosmeticos.kitty.modelo;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/**
 * Entidad que representa un usuario del sistema.
 * Mapeada a la tabla 'usuarios' en la base de datos.
 * @author Erika
 */
@Entity
@Table(name = "usuarios")
public class Usuario {

    /** Identificador único del usuario (llave primaria) */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_usuario")
    private int idUsuario;

    /** Nombre completo del usuario */
    @Column(name = "nombre", nullable = false, length = 100)
    private String nombre;

    /** Correo electrónico usado para iniciar sesión */
    @Column(name = "correo", nullable = false, unique = true, length = 100)
    private String correo;

    /** Contraseña del usuario */
    @Column(name = "contrasena", nullable = false)
    private String contrasena;

    /** Rol del usuario: admin o vendedor */
    @Column(name = "rol")
    private String rol;

    /** Estado del usuario: activo o inactivo */
    @Column(name = "estado")
    private String estado;

    /** Constructor vacío requerido por Hibernate */
    public Usuario() {}

    // ==================== Getters y Setters ====================

    public int getIdUsuario()                           { return idUsuario; }
    public void setIdUsuario(int idUsuario)             { this.idUsuario = idUsuario; }

    public String getNombre()                           { return nombre; }
    public void setNombre(String nombre)                { this.nombre = nombre; }

    public String getCorreo()                           { return correo; }
    public void setCorreo(String correo)                { this.correo = correo; }

    public String getContrasena()                       { return contrasena; }
    public void setContrasena(String contrasena)        { this.contrasena = contrasena; }

    public String getRol()                              { return rol; }
    public void setRol(String rol)                      { this.rol = rol; }

    public String getEstado()                           { return estado; }
    public void setEstado(String estado)                { this.estado = estado; }
}