package com.cosmeticos.kitty.modelo;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/**
 * Entidad que representa un producto del inventario.
 * Mapeada a la tabla 'productos' en la base de datos.
 * @author Erika
 */
@Entity
@Table(name = "productos")
public class Producto {

    /** Identificador único del producto (llave primaria) */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_producto")
    private int idProducto;

    /** Nombre del producto */
    @Column(name = "nombre", nullable = false, length = 100)
    private String nombre;

    /** Descripción detallada del producto */
    @Column(name = "descripcion", length = 255)
    private String descripcion;

    /** Precio de venta del producto */
    @Column(name = "precio", nullable = false)
    private double precio;

    /** Cantidad disponible en inventario */
    @Column(name = "stock", nullable = false)
    private int stock;

    /** Categoría a la que pertenece el producto */
    @Column(name = "id_categoria")
    private int idCategoria;

    /** Fecha en que se registró el producto */
    @Column(name = "fecha_registro")
    private String fechaRegistro;

    /** Estado del producto: 1=activo, 0=inactivo */
    @Column(name = "estado")
    private int estado;

    /** Constructor vacío requerido por Hibernate */
    public Producto() {}

    // ==================== Getters y Setters ====================

    public int getIdProducto()                          { return idProducto; }
    public void setIdProducto(int idProducto)           { this.idProducto = idProducto; }

    public String getNombre()                           { return nombre; }
    public void setNombre(String nombre)                { this.nombre = nombre; }

    public String getDescripcion()                      { return descripcion; }
    public void setDescripcion(String descripcion)      { this.descripcion = descripcion; }

    public double getPrecio()                           { return precio; }
    public void setPrecio(double precio)                { this.precio = precio; }

    public int getStock()                               { return stock; }
    public void setStock(int stock)                     { this.stock = stock; }

    public int getIdCategoria()                         { return idCategoria; }
    public void setIdCategoria(int idCategoria)         { this.idCategoria = idCategoria; }

    public String getFechaRegistro()                    { return fechaRegistro; }
    public void setFechaRegistro(String fechaRegistro)  { this.fechaRegistro = fechaRegistro; }

    public int getEstado()                              { return estado; }
    public void setEstado(int estado)                   { this.estado = estado; }
}